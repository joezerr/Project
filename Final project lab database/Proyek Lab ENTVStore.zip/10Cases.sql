---Case 1
SELECT
	sta.StaffID,
	sta.StaffName,
	vn.VendorName,
	[Total Transaction] = COUNT(dpt.PurchaseTransactionID)
FROM
	DetailPurchaseTransaction dpt JOIN Television tv ON tv.TelevisionID = dpt.TelevisionID 
	JOIN PurchaseTransaction pt ON pt.PurchaseTransactionID = dpt.PurchaseTransactionID 
	JOIN Vendor vn ON vn.VendorID = pt.VendorID 
	JOIN Staff sta ON sta.StaffID = pt.StaffID
WHERE
	pt.PurchaseTransactionDate > '2021-08-01' AND sta.StaffName LIKE 'B%'
GROUP BY sta.StaffId, sta.StaffName, vn.VendorName

---Case 2
SELECT
	RIGHT(cs.CustomerID,3) AS [CustomerID],
	cs.CustomerName,
	dst.SalesQuantity * tv.TelevisionPrice AS [Total Spending]
FROM
	Customer cs JOIN SalesTransaction st ON st.CustomerID = cs.CustomerID 
	JOIN DetailSalesTransaction dst ON st.SalesTransactionID = dst.SalesTransactionID 
	JOIN Television tv ON dst.TelevisionID = tv.TelevisionID
WHERE
	cs.CustomerName LIKE '%a%' AND TelevisionName LIKE '%LED%'

---Case 3
SELECT
	LEFT(sta.StaffName, CHARINDEX(' ',sta.StaffName)) AS [Staff Name],
	tv.TelevisionName AS [TelevisionName],
	tv.TelevisionPrice * dst.SalesQuantity AS [Total Sales]
FROM
	DetailSalesTransaction dst JOIN Television tv ON tv.TelevisionID = dst.TelevisionID 
	JOIN SalesTransaction st ON st.SalesTransactionID = dst.SalesTransactionID 
	JOIN Staff sta ON st.StaffID = sta.StaffID
WHERE
	TelevisionName LIKE '%UHD%' 
GROUP BY sta.StaffName,tv.TelevisionName,tv.TelevisionPrice,dst.SalesQuantity
HAVING COUNT(tv.TelevisionName) > 1

---Case 4
SELECT 
	UPPER(tv.TelevisionName) AS [Television Name],
	CONCAT(MAX(dst.SalesQuantity),' Pc(s)') AS [Max Television Sold],
	CONCAT(SUM(dst.SalesQuantity),' Pc(s)') AS [Total Television Sold]
FROM
	DetailSalesTransaction dst JOIN Television tv ON tv.TelevisionID = dst.TelevisionID 
	JOIN SalesTransaction st ON dst.SalesTransactionID=st.SalesTransactionID
WHERE
	tv.TelevisionPrice > 3000000 AND st.SalesTransactionDate >= '2021-03-01'
GROUP BY tv.TelevisionName
ORDER BY [Total Television Sold] ASC

---Case 5
SELECT 
 VendorName,
 [VendorPhoneNumber] = REPLACE(vn.VendorPhoneNo, '+62', '0'),
 TelevisionName,
 CONCAT('Rp. ', (tv.TelevisionPrice)) AS [TelevisionPrice]

FROM
 DetailPurchaseTransaction dpt JOIN Television tv ON tv.TelevisionID = dpt.TelevisionID 
 JOIN PurchaseTransaction pt ON pt.PurchaseTransactionID = dpt.PurchaseTransactionID 
 JOIN Vendor vn ON pt.VendorID = vn.VendorID,
 (
  SELECT 
   AVG(TelevisionPrice) AS [Television Price]
  FROM
   Television tv
  GROUP BY TelevisionPrice
 )q
 WHERE
  tv.TelevisionPrice > q.[Television Price] AND CHARINDEX(' ',vn.VendorName)!=0
  GROUP BY 
   vn.VendorName,
   vn.VendorPhoneNo,
   tv.TelevisionName,
   tv.TelevisionPrice

---Case 6
SELECT DISTINCT
	sta.StaffID,
	sta.StaffName,
	sta.StaffEmail,
	sta.StaffSalary
FROM
	Staff sta JOIN SalesTransaction st ON sta.StaffID = st.StaffID,(
	SELECT Avg(sta.staffsalary) AS [avg salary]
	FROM Staff sta
	)y, SalesTransaction st2 join Customer cu ON st2.CustomerID = cu.CustomerID
WHERE
	sta.StaffSalary > y.[avg salary] AND cu.CustomerName LIKE '%o%'

--- Case 7
SELECT
 [TelevisionID] = REPLACE(tv.TelevisionID, 'TE', 'Television '),
 TelevisionName,
 UPPER(tb.BrandName) AS [TelevisionBrand],
 CONCAT((dst.SalesQuantity),' Pcs') AS [Total Sold]

FROM
 DetailSalesTransaction dst JOIN Television tv ON tv.TelevisionID = dst.TelevisionID 
 JOIN TelevisionBrand tb ON tb.BrandID = tv.BrandID,
 (
  SELECT 
   AVG(dst.SalesQuantity) AS [Sales Quantity]
  FROM
   DetailSalesTransaction dst
 )x
WHERE
 dst.SalesQuantity > x.[Sales Quantity] AND
 TelevisionName LIKE '%LED%'
GROUP BY 
 tv.TelevisionName,
 tv.TelevisionID,
 dst.SalesQuantity,
 tb.BrandName

ORDER BY [Total Sold] ASC

--- Case 8
SELECT
 VendorName,
 VendorEmail,
 CONCAT('+62',LEFT(VendorPhoneNo,SUBSTRING(VendorPhoneNo,1,LEN(VendorPhoneNo)))) AS [VendorPhoneNo],
 CONCAT(SUM(dpt.PurchaseQuantity), 'Pc(s)') AS [Total Quantity]
FROM
 PurchaseTransaction pt
 JOIN Vendor vn ON vn.VendorID = pt.VendorID
 JOIN DetailPurchaseTransaction dpt ON dpt.PurchaseTransactionID = pt.PurchaseTransactionID
 JOIN Television tv ON tv.TelevisionID = dpt.TelevisionID, (
  SELECT 
   MAX(tv.TelevisionPrice) AS [MaxTVPrice]
  FROM
   Television tv
 )x
WHERE
	CAST(pt.PurchaseTransactionDate AS DATETIME) < MONTH(3) AND 
	CAST(pt.PurchaseTransactionDate AS DATETIME) > MONTH(6) AND 
	tv.TelevisionPrice > x.MaxTVPrice
GROUP BY vn.VendorName,vn.VendorEmail,vn.VendorPhoneNo

--- Case 9
CREATE VIEW [CustomerTransaction] AS
SELECT
 cs.CustomerName,
 cs.CustomerEmail,
 CONCAT(MAX(dst.SalesQuantity),' Pcs') AS [Maximum Quantity Television],
 CONCAT(MIN(dst.SalesQuantity),' Pcs') AS [Minimum Quantity Television]
FROM
 Customer cs JOIN SalesTransaction st ON st.CustomerID = cs.CustomerID
 JOIN DetailSalesTransaction dst ON dst.SalesTransactionID = st.SalesTransactionID
 JOIN DetailPurchaseTransaction dpt ON dpt.TelevisionID = dst.TelevisionID
WHERE
 cs.CustomerName LIKE '%b%'
GROUP BY cs.CustomerName, cs.CustomerEmail
HAVING MAX(dst.SalesQuantity) <> MIN(dst.SalesQuantity)

--- Case 10
CREATE VIEW [StaffTransaction] AS
SELECT
	sta.StaffName,
	sta.StaffEmail,
	sta.StaffPhoneNo,
	COUNT(pt.PurchaseTransactionID) AS [Count Transaction],
	SUM(dpt.PurchaseQuantity) AS [Television Sold]
FROM
	 DetailPurchaseTransaction dpt JOIN PurchaseTransaction pt ON dpt.PurchaseTransactionID = pt.PurchaseTransactionID JOIN Staff sta ON sta.StaffID = pt.StaffID
WHERE
	CAST(pt.PurchaseTransactionDate AS DATETIME) > DAY(10) AND StaffEmail LIKE '%@gmail.com'
GROUP BY 
	sta.StaffName,
	sta.StaffEmail,
	sta.StaffPhoneNo,
	pt.PurchaseTransactionID

